#include "Publication.h"

void check_out(string patron_name, string patron_phone){
	
}