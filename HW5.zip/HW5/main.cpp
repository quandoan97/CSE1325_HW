#include <iostream>
using namespace std;

int execute_cmd(int cmd){
	if(cmd == 0){
		cout<<"Will go to help"<<endl;
	}else if(cmd == 1){
		cout<<"Will go and add a publication to the Library"<<endl;
	}else if(cmd == 2){
		cout<<"Will list out all of the publications that are in the library"<<endl;
	}else if(cmd == 3){
		cout<<"Will go to checkout and give the persons name and phone number to be stored in checkout"<<endl;
	}else if(cmd == 4){
		cout<<"Will add back the Publication as availible to other people"<<endl;
	}
	return cmd;	
}

int main(){
	cout<<"Be gentle with grade, midterms sucks haha"<< endl;
	int choice = 0;
	while(choice!= 9){
		cout<<" C1325 LIBRARY MANAGEMENT SYSTEM" <<endl;
		cout<<"Publications"<<endl;
		cout<<"------------"<<endl;
		cout<<"1. Add publication \n2. List all publication \n3.Check out publication \n4.Check in publication" <<endl;
		cout<<"\nUtility\n-------"<<endl;
		cout<<"9. exit \n0. Help"<<endl;
		
		cin >> choice;
		
		execute_cmd(choice);
	}
	
	return 0;
}

